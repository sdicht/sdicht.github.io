---
marp: true
theme: default
paginate: true

---

# William Shakespeare: *The Tragedy of Othello, the Moor of Venice* (c. 1603)
## English Literature I
### Prof. Pedro Groppo - UFPB

![bg right](Otelo_e_Desdémona_-_Antonio_Muñoz_Degraín.jpg)

---

## Introduction to Renaissance Drama
- Evolved from religious miracle plays (Bible stories) to secular plays about history and morality
- The Privy Council banned religious plays as "too Catholic," forcing this change
- Actors needed noble sponsorship to avoid arrest for vagrancy (hence names like "Lord Strange's Men")

![bg right](1920px-Gilbert_WShakespeares_Plays.jpg)


---

## Key Playwrights
- Christopher Marlowe (1564): Son of shoemaker, Cambridge-educated, wrote *Tamburlaine*, *Doctor Faustus*
- William Shakespeare (1564): Wrote 25+ plays including *Romeo and Juliet*, *Hamlet*, *Henry V*
- Ben Jonson: Former bricklayer/soldier, wrote *Every Man in His Humour*

![bg right](https://upload.wikimedia.org/wikipedia/commons/thumb/0/09/Christopher_Marlowe.jpg/1280px-Christopher_Marlowe.jpg)

---

![bg](Hodge's_conjectural_Globe_reconstruction.jpg)

---

## The Theater Experience
- Cost: 1 penny to stand in yard, extra pennies for gallery seats, 6 pence for private box
- Working people, merchants, nobles, housewives
- Polygonal buildings, open-air with covered galleries
- Minimal props, elaborate costumes, actors performed directly to audience

![bg right](https://upload.wikimedia.org/wikipedia/commons/thumb/1/1f/Shakespeares_Globe_Romeo_and_Juliet_2019.JPG/1920px-Shakespeares_Globe_Romeo_and_Juliet_2019.JPG)

---

## The Theater Experience
- Women forbidden on stage; boys played female roles
- Both Puritans and moralists opposed theater as immoral
- Queen Elizabeth supported drama, created her own company (Queen's Men)
- By 1590s, best actors stayed in London rather than touring

![bg right fit](https://upload.wikimedia.org/wikipedia/commons/thumb/7/77/Restaurante_The_Swan%2C_Londres%2C_Inglaterra%2C_2014-08-11%2C_DD_113.jpg/1920px-Restaurante_The_Swan%2C_Londres%2C_Inglaterra%2C_2014-08-11%2C_DD_113.jpg)

---

## The Text

- Written to be acted on the stage, not read
- What we have is a script made after the fact, not one the working scripts - published after Shakespeare's death
- No single, authoritative text of Shakespeare's plays - they varied even in early editions
- Unlike today's published plays, Shakespeare often integrates actions into the dialogue rather than relying on explicit stage directions
    - Desdemona: "Here I kneel"
- No elaborate scenery or lighting - imagery and descriptive language were crucial for creating the play's world
    - e.g. In Act 1, Iago's crude descriptions of Othello ("old black ram," "Barbary horse")

---

![bg](Othello_F1.jpg)

---

![bg](../../assets/othello_1.jpeg)

---

![bg fit](../../assets/othello_0.jpeg)

---

## Medieval Morality Plays

* Morality play - medieval allegorical theatrical form in which moral lessons were taught through characters who personify moral qualities, like charity or vice. 
* Example: *Mankind* (c. 1465) - Newguise, Nowadays and Nought), try to tempt Mankind, a farmer, away from Mercy and who actively endeavour to lure him to commit vices such as avarice, lust and gluttony.

![bg right fit](https://internetshakespeare.uvic.ca/Library/SLT/media/images/MoralityFigures.JPG)

---

## The Vice Character

- A temptation figure who embodies worldly pleasures;  often has the most important role
* The Vice interacts directly with the audience, often breaking the fourth wall
* Performs his worldliness by dressing as an Egyptian or a Turk with the aid of blackface and red-face makeup

### Shakespeare
* Incorporates elements of morality plays, such as the Vice figure and the struggle between good and evil, into his plays like *Richard III*, *Titus Andronicus,* and *Henry IV*
* Vice = Iago, not Othello: manipulates events and leads Othello down a path of destruction.

---

## Comedy vs Tragedy

- Shakespeare uses familiar aspects of the morality  play to mislead the audience’s expectations as well as comedy
- Comedic elements: the disobedient daughter (cf. *Midsummer Night's Dream*) and the cuckolded husband
- Chaucer influence: older husbands cuckolded by younger wives (The Merchant's Tale, The Miller's Tale)

![bg right](Edwin_Landseer_-_Scene_from_A_Midsummer_Night's_Dream._Titania_and_Bottom_-_Google_Art_Project.jpg)

---

## Sources

- Giovanni Battista Giraldi (aka Cinthio), in *Gli Hecatommithi* (1565)

> I fear greatly that I shall be a warning to young girls not to marry against their parents’ wishes; and Italian ladies will learn by my example not to tie themselves to a man whom Nature, Heaven, and manner of life separate from us. 

(Disdemona)

![bg right](https://upload.wikimedia.org/wikipedia/commons/b/b1/Othello_and_Desdemona_in_Venice_by_Théodore_Chassériau.jpg)

---

## What was a Moor?

![bg right fit](../../assets/othello_5.jpeg)

- Elastic term in the early modern period, could encompass 
	- Muslims (religious), 
	- Africans (geographical), 
	- blacks (racial), 
	- atheists (non-religious) and other groups

---

![bg right](../../assets/othello_6.jpeg)

> native or inhabitant of ancient Mauretania [Morocco and Algeria]. Later ... a member of a Muslim people of mixed Berber and Arab descent inhabiting north-western Africa, who in the 8th C. conquered Spain. In the Middle Ages up to 17th C., Moors were mostly black or very dark-skinned, although the existence of ‘white Moors’ was recognized. Thus the term was often used, even into the 20th C., with the sense ‘black person.’ (OED)

---

## Is Othello Black?

- Text suggests he was portrayed as black on the early modern stage
- Racialized rhetoric comes from Roderigo, Iago and Brabantio before the audience ever sees Othello
- Is this metadramatic = how Othello should be performed?
- Only in the 19th century Othello’s blackness was questioned by scholars and actors

![bg right](../../assets/othello_2.jpeg)

---

## Moor vs Turk

- Early modern English texts portrayed Turks as barbarous, cruel, despotic, tyrannical, and sexually voracious.
- The Turks were perceived as a threat to Western civilization militarily, economically, and sexually.
- The term “Turk” was used to refer to the Turkish people, Muslims in general, and the Ottoman Empire.

![bg right fit](Thomas_Keene_in_Othello_1884_Poster.JPG)	

---

## Othello and the audience

- Unlike other Shakespearean tragedies where the audience is on equal footing with the hero, Othello’s audience knows more, prompting a different emotional response.
- The audience’s knowledge often leads to discomfort and a desire to intervene, as seen in historical anecdotes.
- The play’s uneven structure forces the audience to choose a side.

![bg right](../../assets/othello_11.jpeg)

---

## Criticism

- A.C. Bradley: *Othello* is Shakespeare's best tragedy, surpassing *Hamlet* and *Macbeth*, due to its intense drama, modern themes, and relatable characters.
- Othello’s focus on **private matters**, particularly sexual jealousy, makes it more emotionally impactful than plays centered around state affairs.
- Challenged Coleridge’s interpretation of Othello’s race: Shakespeare **intended Othello to be black**.
- Shakespeare’s plays, particularly *Othello*, are better experienced through **reading** than performance: discomfort of seeing Othello’s race onstage.
- Shakespeare’s plays were primarily experienced as performances during his time, by the early 19th century, they were increasingly studied and read as literary works.

---

## Iago: a perfect combination of the two facts concerning evil (A.C. Bradley)
- "perfectly sane people exist in whom fellow-feeling of any kind is so weak that an almost absolute egoism becomes possible to them" + "exceptional powers of will and intellect"
- absurd "to compare Iago with the Satan of *Paradise Lost*" ... "so immensely does [he] exceed Milton's Fiend in evil".

![bg right](ParadiseLButts1.jpg)

---

![bg right](https://upload.wikimedia.org/wikipedia/commons/8/8f/Edwin_Booth_as_Iago.jpg)

---

- Recently, scholars and artists began to question race, gender, and representation 
- Othello becomes a text through which contemporary issues of race, politics, and colonialism can be explored.
- Possible reading: Othello is not a fully formed character but a white myth or stereotype about black masculinity.
	•	Black People’s Response to Othello: Black people’s response to Othello is complex, marked by empathy for white people’s inability to empathize with them.
	•	Othello’s Impact on Racial Tensions: Othello’s presence on stage serves as a reminder of the historical bond between black and white people, potentially adding to racial tensions.
	•	Racial Difference in Performance: The display of Black people and the simulation of Blackness are crucial in articulating racial difference.
	•	Power Dynamics in Performance: Exhibition modes give power to the audience, while mimetic modes give power to the actors, but for Black and female actors, these modes often overlap, limiting their control.
	•	Historical Context of Othello Performances: This framework helps understand the challenges of performing Othello in different historical periods.
---
> Can we imagine him [Shakespeare] so utterly ignorant as to make a barbarous negro plead royal birth, – at a time, too, when negroes were not known except as slaves? . . . Besides, if we could in good earnest believe Shakespeare ignorant of the distinction [between a Moor and a ‘negro’], still why should we adopt one disagreeable possibility instead of a ten times greater and more pleasing probability? It is a common error to mistake epithets applied by the dramatis personae to each other as truly descriptive of what the audience ought to see or know. No doubt Desdemona saw Othello’s visage in his mind; yet, as we are constituted, and most surely as an English audience was disposed in the beginning of the seventeenth century, it would be something monstrous to conceive this beautiful Venetian girl falling in love with a veritable negro. It would argue a disproportionateness, a want of balance, in Desdemona, which Shakespeare does not appear to have in the least contemplated. (Coleridge, 385–6)

---

.
None other than Samuel Taylor Coleridge appears to be the fi rst
to question the validity of portraying Othello as a black man. In
1818 he wrote:

. The Oxford English
Dictionary provides the following defi nition for Moor:

 Unnamed Moor who lives in Venice proves himself ‘valiant’ and ‘skillful’
- Disdemona, ‘virtuous Lady of wondrous beauty’, whose name in Italian means unlucky or ill-omened, falls in love with the Moor ‘impelled not by female appetite
but by the Moor’s good qualities’
- ‘the Lady’s relatives did all they could to make her take another husband’. 
- While there is no Turkish threat to Cyprus in Cinthio, the Signoria send the Moor ‘to maintain Cyprus’. 
- The unnamed Ensign who accompanies the Moor to Cyprus, ‘fell ardently in love with Disdemona, and bent all his thoughts to see if he could manage to enjoy her’.

---

 Because Disdemona remains


![bg](image-2.jpeg)

---

![bg](image-2.jpeg)
![bg fit](image-3.jpeg)

---

![bg fit](image-4.jpeg)
William Haviland

---

![bg fit](image-5.jpeg)

Jan Jansz Mostaert,
*Portrait of an African 
Man (Christophle le 
More?)* (c. 1474-1552) 

---

![bg fit](image-6.jpeg)

Peter Paul Rubens, 
*Mulay Ahmad* 
(c. 1609)

---

![bg fit](image-7.jpeg)

Georgius Jehner
von Orlamünde,
*Members of the 
Theban Legion*

---

![bg w:550](image-8.jpeg)

Charles Taylor,
1793 print

---

![bg fit](image-9.jpeg)

---

![bg fit](image-10.jpeg)

---

![bg fit](image-11.jpeg)


---

![bg fit](image-12.jpeg)

---

![bg fit](image-13.jpeg)

---

![bg fit](image-14.jpeg)

Paul Robeson 
as Othello

---

![bg](image-15.jpeg)